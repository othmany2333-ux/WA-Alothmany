WA Al-othmany v0.3.1 FIX1

Fixes the real parser bug that caused:
WhatsAppGroupParserTest > archivedEntryIsDetected FAILED

Cause:
Arabic text normalization converts taa marbuta (ة) to haa (ه), so
"المؤرشفة" becomes "المؤرشفه" before comparison. The archived-label
lexicon did not include the normalized form.

This patch fixes the parser itself and keeps the unit test unchanged.
