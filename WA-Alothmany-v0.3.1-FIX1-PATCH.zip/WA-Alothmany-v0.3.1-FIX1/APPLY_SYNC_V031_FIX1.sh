#!/usr/bin/env bash
set -euo pipefail

ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
cd "$ROOT"
FILE="app/src/main/java/com/alothmany/wa/feature/sync/engine/WhatsAppGroupParser.kt"

if [ ! -f "$FILE" ]; then
  echo "ERROR: $FILE not found"
  exit 1
fi

python3 - <<'PY'
from pathlib import Path
p = Path("app/src/main/java/com/alothmany/wa/feature/sync/engine/WhatsAppGroupParser.kt")
s = p.read_text(encoding="utf-8")
old = '''    private val archivedLabels = setOf(\n        "archived", "archived chats", "مؤرشفة", "المؤرشفة", "المؤرشف", "الدردشات المؤرشفة"\n    )'''
new = '''    // UI labels are normalized before comparison. Arabic normalization changes\n    // taa marbuta (ة) to haa (ه), so keep normalized archived variants here too.\n    private val archivedLabels = setOf(\n        "archived", "archived chats",\n        "مؤرشفة", "مؤرشفه",\n        "المؤرشفة", "المؤرشفه",\n        "المؤرشف",\n        "الدردشات المؤرشفة", "الدردشات المؤرشفه"\n    )'''
if old not in s:
    if '"المؤرشفه"' in s and '"الدردشات المؤرشفه"' in s:
        print("Parser already contains normalized archived labels; no source edit needed.")
    else:
        raise SystemExit("ERROR: expected archivedLabels block not found; repository may have changed.")
else:
    s = s.replace(old, new, 1)
    p.write_text(s, encoding="utf-8")
    print("Fixed Arabic archived-label normalization in WhatsAppGroupParser.kt")
PY

# Fast static verification before committing.
grep -q '"المؤرشفه"' "$FILE"
grep -q '"الدردشات المؤرشفه"' "$FILE"

echo "Running the focused parser unit test..."
./gradlew testDebugUnitTest --tests 'com.alothmany.wa.feature.sync.engine.WhatsAppGroupParserTest' --stacktrace

git add "$FILE"
if git diff --cached --quiet; then
  echo "No new changes to commit."
else
  git commit -m "Fix archived Arabic label detection in Smart Sync v0.3.1"
  git push origin main
fi

echo "DONE: v0.3.1 FIX1 applied and pushed. GitHub Actions will run automatically."
