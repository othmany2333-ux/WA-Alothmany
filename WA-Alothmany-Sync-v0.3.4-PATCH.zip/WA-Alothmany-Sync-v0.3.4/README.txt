WA Al-othmany Smart Sync v0.3.4 patch

Fixes:
- Passive WhatsApp search box no longer makes the Chats screen look like active SEARCH.
- Accessibility snapshots now include focused/editable state.
- Chat-list detection no longer depends on every WhatsApp row being clickable.
- Parser can discover non-clickable structural rows and text-band fallbacks.
- Fallback screen fingerprint keeps scrolling reliable on unusual WhatsApp layouts.
- Regression tests cover passive search, focused search, channels, and non-clickable rows.
- App version becomes 0.3.4 and CI artifact becomes wa-al-othmany-debug-v0.3.4.

Apply from repository root:
  unzip -o WA-Alothmany-Sync-v0.3.4-PATCH.zip
  bash WA-Alothmany-Sync-v0.3.4/APPLY_SYNC_V034.sh
