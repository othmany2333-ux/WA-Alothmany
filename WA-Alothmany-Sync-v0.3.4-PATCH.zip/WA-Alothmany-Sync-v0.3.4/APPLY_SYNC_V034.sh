#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
if [ ! -f "$ROOT/app/build.gradle.kts" ]; then
  echo "ERROR: Run this script from the WA-Alothmany repository root."
  exit 1
fi

python3 - <<'PY'
from pathlib import Path

root = Path.cwd()

def read(rel):
    p = root / rel
    if not p.exists():
        raise SystemExit(f"Missing required file: {rel}")
    return p.read_text(encoding="utf-8")

def write(rel, text):
    p = root / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding="utf-8")

def replace_once(rel, old, new):
    text = read(rel)
    if new in text:
        return
    if old not in text:
        raise SystemExit(f"Expected block not found in {rel}; repository may not be on v0.3.3.")
    write(rel, text.replace(old, new, 1))

bridge = "app/src/main/java/com/alothmany/wa/system/accessibility/WhatsAppUiBridge.kt"
replace_once(
    bridge,
    '''    val enabled: Boolean,
    val depth: Int,
    val bounds: RectSnapshot,
)''',
    '''    val enabled: Boolean,
    val depth: Int,
    val bounds: RectSnapshot,
    val focused: Boolean = false,
    val editable: Boolean = false,
)'''
)

service = "app/src/main/java/com/alothmany/wa/system/accessibility/WAAccessibilityService.kt"
replace_once(
    service,
    '''                depth = depth,
                bounds = RectSnapshot.from(rect),
            )''',
    '''                depth = depth,
                bounds = RectSnapshot.from(rect),
                focused = node.isFocused,
                editable = node.isEditable,
            )'''
)

parser = "app/src/main/java/com/alothmany/wa/feature/sync/engine/WhatsAppGroupParser.kt"
text = read(parser)
if "import com.alothmany.wa.system.accessibility.RectSnapshot" not in text:
    text = text.replace(
        "import com.alothmany.wa.feature.sync.model.ParsedGroupScreen\n",
        "import com.alothmany.wa.feature.sync.model.ParsedGroupScreen\nimport com.alothmany.wa.system.accessibility.RectSnapshot\n",
        1,
    )

old_rows = '''        val rowNodes = snapshot.nodes.asSequence()
            .filter { it.enabled && it.clickable }
            .filter { it.bounds.width >= minRowWidth }
            .filter { it.bounds.height in minRowHeight..maxRowHeight }
            .filter { it.bounds.top >= contentTop && it.bounds.bottom <= snapshot.height }
            .distinctBy { listOf(it.bounds.left, it.bounds.top, it.bounds.right, it.bounds.bottom) }
            .sortedBy { it.bounds.top }
            .toList()

        val parsedRows = rowNodes.mapNotNull { row -> parseRow(snapshot, row) }
        val groups = parsedRows.mapNotNull { it.group }
            .distinctBy { it.identityFingerprint }

        return ParsedGroupScreen(
            groups = groups,
            screenFingerprint = fingerprint(parsedRows.map { it.observationFingerprint }),
            looksLikeChatList = parsedRows.size >= 2,
            hasArchivedEntry = hasArchivedEntry,
            chatRowCount = parsedRows.size,
        )
    }

    private data class ParsedRow('''

new_rows = '''        val rowNodes = discoverRowNodes(
            snapshot = snapshot,
            minRowHeight = minRowHeight,
            maxRowHeight = maxRowHeight,
            minRowWidth = minRowWidth,
            contentTop = contentTop,
        )

        val parsedRows = rowNodes
            .mapNotNull { row -> parseRow(snapshot, row) }
            .distinctBy { it.observationFingerprint }

        val groups = parsedRows.mapNotNull { it.group }
            .distinctBy { it.identityFingerprint }

        val fallbackFingerprintParts = snapshot.nodes.asSequence()
            .filter { it.bounds.top >= contentTop && it.bounds.bottom <= (snapshot.height * 0.92f).toInt() }
            .flatMap { node -> sequenceOf(node.text, node.contentDescription) }
            .mapNotNull(::cleanLabel)
            .map(::normalize)
            .filter { it.isNotBlank() }
            .filterNot { it in ignoredExact }
            .take(120)
            .toList()

        val screenParts = parsedRows
            .map { it.observationFingerprint }
            .ifEmpty { fallbackFingerprintParts }

        val hasPrimaryScrollableList = snapshot.nodes.any { node ->
            node.scrollable &&
                node.bounds.width >= (snapshot.width * 0.52f).toInt() &&
                node.bounds.height >= (snapshot.height * 0.28f).toInt()
        }

        return ParsedGroupScreen(
            groups = groups,
            screenFingerprint = fingerprint(screenParts),
            looksLikeChatList = parsedRows.size >= 2 || hasPrimaryScrollableList,
            hasArchivedEntry = hasArchivedEntry,
            chatRowCount = parsedRows.size,
        )
    }

    /**
     * WhatsApp builds chat rows differently across releases/OEMs. Some versions
     * expose the whole row as clickable; others expose a non-clickable container.
     * We therefore discover rows from geometry + contained text and add a
     * text-band fallback when no stable row container is exposed.
     */
    private fun discoverRowNodes(
        snapshot: WhatsAppUiSnapshot,
        minRowHeight: Int,
        maxRowHeight: Int,
        minRowWidth: Int,
        contentTop: Int,
    ): List<WhatsAppUiNode> {
        val contentBottom = (snapshot.height * 0.92f).toInt()

        val structural = snapshot.nodes.asSequence()
            .filter { it.enabled && !it.scrollable }
            .filter { it.bounds.width >= minRowWidth }
            .filter { it.bounds.height in minRowHeight..maxRowHeight }
            .filter { it.bounds.top >= contentTop && it.bounds.bottom <= contentBottom }
            .filter { node ->
                node.clickable || meaningfulTextCount(snapshot, node) >= 2
            }
            .toList()

        val inferred = inferTextBandRows(snapshot, contentTop, contentBottom, maxRowHeight)
        val all = structural + inferred
        if (all.isEmpty()) return emptyList()

        val tolerance = (snapshot.height * 0.025f).toInt().coerceAtLeast(18)
        val selected = mutableListOf<WhatsAppUiNode>()

        all.sortedBy { it.bounds.top }.forEach { candidate ->
            val center = (candidate.bounds.top + candidate.bounds.bottom) / 2
            val existingIndex = selected.indexOfFirst { existing ->
                val existingCenter = (existing.bounds.top + existing.bounds.bottom) / 2
                kotlin.math.abs(existingCenter - center) <= tolerance
            }

            if (existingIndex < 0) {
                selected += candidate
            } else {
                val existing = selected[existingIndex]
                if (rowQuality(snapshot, candidate) > rowQuality(snapshot, existing)) {
                    selected[existingIndex] = candidate
                }
            }
        }

        return selected.sortedBy { it.bounds.top }
    }

    private fun inferTextBandRows(
        snapshot: WhatsAppUiSnapshot,
        contentTop: Int,
        contentBottom: Int,
        maxRowHeight: Int,
    ): List<WhatsAppUiNode> {
        val textNodes = snapshot.nodes.asSequence()
            .filter { it.bounds.width > 0 && it.bounds.height > 0 }
            .filter { it.bounds.top >= contentTop && it.bounds.bottom <= contentBottom }
            .filter { node ->
                val raw = cleanLabel(node.text) ?: cleanLabel(node.contentDescription)
                raw != null && normalize(raw).let { value ->
                    value.isNotBlank() && value !in ignoredExact && value.length <= 180
                }
            }
            .sortedBy { (it.bounds.top + it.bounds.bottom) / 2 }
            .toList()

        if (textNodes.size < 2) return emptyList()

        val bandGap = (snapshot.height * 0.043f).toInt().coerceAtLeast(36)
        val bands = mutableListOf<MutableList<WhatsAppUiNode>>()

        textNodes.forEach { node ->
            val center = (node.bounds.top + node.bounds.bottom) / 2
            val current = bands.lastOrNull()
            if (current == null) {
                bands += mutableListOf(node)
            } else {
                val currentCenter = current.map { (it.bounds.top + it.bounds.bottom) / 2 }.average().toInt()
                if (kotlin.math.abs(center - currentCenter) <= bandGap) {
                    current += node
                } else {
                    bands += mutableListOf(node)
                }
            }
        }

        return bands.mapNotNull { band ->
            val labels = band.mapNotNull { node ->
                cleanLabel(node.text) ?: cleanLabel(node.contentDescription)
            }.map(::normalize).distinct()

            val plausibleTitles = labels.filter(::isPossibleTitle)
            if (labels.size < 2 || plausibleTitles.isEmpty()) return@mapNotNull null

            val top = (band.minOf { it.bounds.top } - 8).coerceAtLeast(contentTop)
            val bottom = (band.maxOf { it.bounds.bottom } + 8).coerceAtMost(contentBottom)
            if (bottom <= top || bottom - top > maxRowHeight) return@mapNotNull null

            WhatsAppUiNode(
                text = null,
                contentDescription = null,
                className = "synthetic.ChatRow",
                viewId = "synthetic_chat_row",
                clickable = false,
                scrollable = false,
                enabled = true,
                depth = 0,
                bounds = RectSnapshot(0, top, snapshot.width, bottom),
            )
        }
    }

    private fun meaningfulTextCount(snapshot: WhatsAppUiSnapshot, row: WhatsAppUiNode): Int =
        snapshot.nodes.asSequence()
            .filter { node -> row.bounds.contains(node.bounds) }
            .flatMap { node -> sequenceOf(node.text, node.contentDescription) }
            .mapNotNull(::cleanLabel)
            .map(::normalize)
            .filter { it.isNotBlank() && it !in ignoredExact }
            .filterNot { timeRegex.matches(it) || dateRegex.matches(it) || countRegex.matches(it) }
            .distinct()
            .take(6)
            .count()

    private fun rowQuality(snapshot: WhatsAppUiSnapshot, row: WhatsAppUiNode): Int {
        val textScore = meaningfulTextCount(snapshot, row).coerceAtMost(6) * 18
        val clickScore = if (row.clickable) 80 else 0
        val realContainerScore = if (row.viewId == "synthetic_chat_row") 0 else 24
        val widthScore = (row.bounds.width * 12 / snapshot.width.coerceAtLeast(1)).coerceAtMost(12)
        return textScore + clickScore + realContainerScore + widthScore
    }

    private data class ParsedRow('''

if new_rows not in text:
    if old_rows not in text:
        raise SystemExit("Parser v0.3.3 row-discovery block not found.")
    text = text.replace(old_rows, new_rows, 1)

old_title = '''        val titlePair = usableText
            .filter { (node, _) -> node.bounds.top <= row.bounds.top + (row.bounds.height * 0.62f) }
            .sortedWith('''
new_title = '''        val titlePair = usableText
            .filter { (_, raw) -> isPossibleTitle(normalize(raw)) }
            .filter { (node, _) -> node.bounds.top <= row.bounds.top + (row.bounds.height * 0.62f) }
            .sortedWith('''
if new_title not in text:
    if old_title not in text:
        raise SystemExit("Parser title-selection block not found.")
    text = text.replace(old_title, new_title, 1)

write(parser, text)

detector = r'''package com.alothmany.wa.feature.sync.engine

import com.alothmany.wa.feature.sync.model.ParsedGroupScreen
import com.alothmany.wa.system.accessibility.WhatsAppUiSnapshot
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

enum class WhatsAppSurface {
    CHAT_LIST,
    ARCHIVED_LIST,
    SEARCH,
    CHANNELS_OR_UPDATES,
    COMMUNITIES,
    CALLS,
    OPEN_CHAT,
    UNKNOWN,
}

@Singleton
class WhatsAppScreenDetector @Inject constructor() {
    private val chatLabels = setOf("chats", "chat", "المحادثات", "الدردشات", "محادثات", "دردشات")
    private val archivedLabels = setOf("archived", "archived chats", "مؤرشفه", "المؤرشفه", "المؤرشف", "الدردشات المؤرشفه")
    private val searchTokens = setOf("search chats", "search", "بحث", "ابحث")
    private val channelTokens = setOf(
        "channels", "channel", "updates", "status", "statuses",
        "القنوات", "القناه", "التحديثات", "الحاله"
    )
    private val communityTokens = setOf("communities", "community", "المجتمعات", "مجتمع")
    private val callsTokens = setOf("calls", "call", "المكالمات", "مكالمات")
    private val openChatTokens = setOf(
        "video call", "voice call", "contact info",
        "مكالمه فيديو", "مكالمه صوتيه", "معلومات جهه الاتصال"
    )

    fun classify(snapshot: WhatsAppUiSnapshot, parsed: ParsedGroupScreen): WhatsAppSurface {
        val labels = snapshot.nodes.mapNotNull { node ->
            listOfNotNull(node.text, node.contentDescription)
                .joinToString(" ")
                .takeIf { it.isNotBlank() }
                ?.let(::normalize)
        }

        val topLabels = snapshot.nodes.asSequence()
            .filter { it.bounds.top <= snapshot.height * 0.33f }
            .mapNotNull { node ->
                listOfNotNull(node.text, node.contentDescription)
                    .joinToString(" ")
                    .takeIf { it.isNotBlank() }
                    ?.let(::normalize)
            }
            .toList()

        // Modern WhatsApp may keep a passive search EditText on the Chats screen.
        // It is a SEARCH surface only when that field is actually focused.
        val focusedSearch = snapshot.nodes.any { node ->
            node.focused &&
                (node.editable || node.className?.contains("EditText", ignoreCase = true) == true)
        }
        if (focusedSearch) return WhatsAppSurface.SEARCH

        if (topLabels.any { label -> channelTokens.any { token -> label == token || label.startsWith("$token ") } }) {
            return WhatsAppSurface.CHANNELS_OR_UPDATES
        }
        if (topLabels.any { label -> communityTokens.any { token -> label == token || label.startsWith("$token ") } }) {
            return WhatsAppSurface.COMMUNITIES
        }
        if (topLabels.any { label -> callsTokens.any { token -> label == token || label.startsWith("$token ") } }) {
            return WhatsAppSurface.CALLS
        }

        val hasPrimaryScrollable = snapshot.nodes.any { node ->
            node.scrollable &&
                node.bounds.width >= (snapshot.width * 0.52f).toInt() &&
                node.bounds.height >= (snapshot.height * 0.28f).toInt()
        }

        val topArchived = topLabels.any { label ->
            archivedLabels.any { archived -> label == archived || label.startsWith("$archived ") }
        }
        if (topArchived && (parsed.chatRowCount > 0 || parsed.looksLikeChatList || hasPrimaryScrollable)) {
            return WhatsAppSurface.ARCHIVED_LIST
        }

        val chatTabVisible = labels.any { label ->
            chatLabels.any { chat ->
                label == chat ||
                    label.startsWith("$chat,") ||
                    label.startsWith("$chat،") ||
                    label.endsWith(" $chat") ||
                    label.endsWith("، $chat") ||
                    label.endsWith(", $chat") ||
                    (label.contains("tab") && label.contains(chat)) ||
                    (label.contains("علامه تبويب") && label.contains(chat))
            }
        }

        val negativeTopSurface = containsNegativeSurface(topLabels)

        if (chatTabVisible && hasPrimaryScrollable && !negativeTopSurface) {
            return WhatsAppSurface.CHAT_LIST
        }

        if (chatTabVisible && parsed.chatRowCount >= 1 && !negativeTopSurface) {
            return WhatsAppSurface.CHAT_LIST
        }

        if (parsed.looksLikeChatList && hasPrimaryScrollable && !negativeTopSurface) {
            return WhatsAppSurface.CHAT_LIST
        }

        if (parsed.chatRowCount >= 2 && !negativeTopSurface) {
            return WhatsAppSurface.CHAT_LIST
        }

        // A passive search label on Chats is not enough to call the whole screen SEARCH.
        val passiveSearchLabel = topLabels.any { label -> searchTokens.any { token -> token in label } }
        if (passiveSearchLabel && !hasPrimaryScrollable && parsed.chatRowCount == 0) {
            return WhatsAppSurface.SEARCH
        }

        if (topLabels.any { label -> openChatTokens.any { it in label } }) {
            return WhatsAppSurface.OPEN_CHAT
        }

        return WhatsAppSurface.UNKNOWN
    }

    private fun containsNegativeSurface(labels: List<String>): Boolean = labels.any { label ->
        channelTokens.any { it in label } ||
            communityTokens.any { it in label } ||
            callsTokens.any { it in label }
    }

    private fun normalize(value: String): String = value
        .trim()
        .lowercase(Locale.ROOT)
        .replace('أ', 'ا')
        .replace('إ', 'ا')
        .replace('آ', 'ا')
        .replace('ى', 'ي')
        .replace('ة', 'ه')
        .replace(Regex("[ًٌٍَُِّْـ]"), "")
        .replace(Regex("\\s+"), " ")
}
'''
write("app/src/main/java/com/alothmany/wa/feature/sync/engine/WhatsAppScreenDetector.kt", detector)

screen_test = r'''package com.alothmany.wa.feature.sync.engine

import com.alothmany.wa.system.accessibility.RectSnapshot
import com.alothmany.wa.system.accessibility.WhatsAppUiNode
import com.alothmany.wa.system.accessibility.WhatsAppUiSnapshot
import org.junit.Assert.assertEquals
import org.junit.Test

class WhatsAppScreenDetectorTest {
    private val parser = WhatsAppGroupParser()
    private val detector = WhatsAppScreenDetector()

    @Test
    fun normalChatListIsAcceptedBeforeAnyBackAction() {
        val snapshot = snapshot(
            listOf(
                label("الدردشات", 2250),
                primaryList(),
                row(220, "محمد", "مرحبا"),
                row(400, "طلاب الجامعة", "~ Ahmed: المحاضرة"),
                row(580, "خالد", "رسالة"),
            ).flatten()
        )
        assertEquals(WhatsAppSurface.CHAT_LIST, detector.classify(snapshot, parser.parse(snapshot)))
    }

    @Test
    fun passiveSearchBoxInsideChatsIsStillChatList() {
        val search = WhatsAppUiNode(
            text = "بحث...", contentDescription = "Search chats", className = "android.widget.EditText",
            viewId = "search", clickable = true, scrollable = false, enabled = true, depth = 3,
            bounds = RectSnapshot(50, 80, 1000, 180),
            focused = false, editable = true,
        )
        val snapshot = snapshot(
            listOf(search, label("الدردشات", 2250).single(), primaryList().single()) +
                row(260, "طلاب الجامعة", "~ Ahmed: hi") +
                row(440, "محمد", "مرحبا")
        )
        assertEquals(WhatsAppSurface.CHAT_LIST, detector.classify(snapshot, parser.parse(snapshot)))
    }

    @Test
    fun focusedSearchFieldIsSearchSurface() {
        val edit = WhatsAppUiNode(
            text = "بحث...", contentDescription = "Search chats", className = "android.widget.EditText",
            viewId = "search", clickable = true, scrollable = false, enabled = true, depth = 3,
            bounds = RectSnapshot(50, 80, 1000, 180),
            focused = true, editable = true,
        )
        val snapshot = snapshot(
            listOf(edit, label("الدردشات", 2250).single(), primaryList().single()) +
                row(260, "طلاب الجامعة", "~ Ahmed: hi")
        )
        assertEquals(WhatsAppSurface.SEARCH, detector.classify(snapshot, parser.parse(snapshot)))
    }

    @Test
    fun channelsSurfaceIsRejectedEvenWhenRowsExist() {
        val snapshot = snapshot(
            listOf(
                label("القنوات", 90),
                label("الدردشات", 2250),
                primaryList(),
                row(250, "قناة تقنية", "آخر تحديث"),
                row(440, "قناة أخبار", "خبر جديد"),
                row(630, "قناة ثالثة", "تحديث"),
            ).flatten()
        )
        assertEquals(WhatsAppSurface.CHANNELS_OR_UPDATES, detector.classify(snapshot, parser.parse(snapshot)))
    }

    private fun snapshot(nodes: List<WhatsAppUiNode>) = WhatsAppUiSnapshot(
        packageName = "com.whatsapp",
        eventType = 0,
        capturedAt = System.currentTimeMillis(),
        rootBounds = RectSnapshot(0, 0, 1080, 2400),
        nodes = nodes,
    )

    private fun primaryList() = listOf(
        WhatsAppUiNode(
            text = null, contentDescription = null, className = "androidx.recyclerview.widget.RecyclerView",
            viewId = "chat_list", clickable = false, scrollable = true, enabled = true, depth = 2,
            bounds = RectSnapshot(0, 180, 1080, 2180),
        )
    )

    private fun label(text: String, top: Int) = listOf(
        WhatsAppUiNode(
            text = text, contentDescription = text, className = "android.widget.TextView", viewId = "label",
            clickable = false, scrollable = false, enabled = true, depth = 3,
            bounds = RectSnapshot(100, top, 900, top + 60),
        )
    )

    private fun row(top: Int, title: String, preview: String) = listOf(
        WhatsAppUiNode(
            text = null, contentDescription = null, className = "android.view.ViewGroup", viewId = "chat_row",
            clickable = true, scrollable = false, enabled = true, depth = 4,
            bounds = RectSnapshot(20, top, 1060, top + 170),
        ),
        WhatsAppUiNode(
            text = title, contentDescription = null, className = "android.widget.TextView", viewId = "title",
            clickable = false, scrollable = false, enabled = true, depth = 5,
            bounds = RectSnapshot(240, top + 12, 950, top + 62),
        ),
        WhatsAppUiNode(
            text = preview, contentDescription = null, className = "android.widget.TextView", viewId = "preview",
            clickable = false, scrollable = false, enabled = true, depth = 5,
            bounds = RectSnapshot(240, top + 75, 950, top + 128),
        )
    )
}
'''
write("app/src/test/java/com/alothmany/wa/feature/sync/engine/WhatsAppScreenDetectorTest.kt", screen_test)

structural_test = r'''package com.alothmany.wa.feature.sync.engine

import com.alothmany.wa.system.accessibility.RectSnapshot
import com.alothmany.wa.system.accessibility.WhatsAppUiNode
import com.alothmany.wa.system.accessibility.WhatsAppUiSnapshot
import org.junit.Assert.assertTrue
import org.junit.Test

class WhatsAppStructuralRowParserTest {
    private val parser = WhatsAppGroupParser()

    @Test
    fun nonClickableChatContainersAreStillRead() {
        val nodes = mutableListOf<WhatsAppUiNode>()
        nodes += primaryList()
        nodes += row(240, "طلاب الجامعة", "~ Ahmed: المحاضرة", clickable = false)
        nodes += row(430, "محمد", "مرحبا", clickable = false)
        nodes += row(620, "قروب التقنية", "Ali: update", clickable = false)

        val parsed = parser.parse(snapshot(nodes))
        assertTrue(parsed.chatRowCount >= 2)
        assertTrue(parsed.groups.any { it.displayName == "طلاب الجامعة" })
    }

    private fun snapshot(nodes: List<WhatsAppUiNode>) = WhatsAppUiSnapshot(
        packageName = "com.whatsapp",
        eventType = 0,
        capturedAt = System.currentTimeMillis(),
        rootBounds = RectSnapshot(0, 0, 1080, 2400),
        nodes = nodes,
    )

    private fun primaryList() = WhatsAppUiNode(
        text = null, contentDescription = null, className = "android.view.ViewGroup", viewId = "chat_list",
        clickable = false, scrollable = true, enabled = true, depth = 2,
        bounds = RectSnapshot(0, 190, 1080, 2180),
    )

    private fun row(top: Int, title: String, preview: String, clickable: Boolean) = listOf(
        WhatsAppUiNode(
            text = null, contentDescription = null, className = "android.view.ViewGroup", viewId = null,
            clickable = clickable, scrollable = false, enabled = true, depth = 4,
            bounds = RectSnapshot(15, top, 1065, top + 170),
        ),
        WhatsAppUiNode(
            text = title, contentDescription = null, className = "android.widget.TextView", viewId = null,
            clickable = false, scrollable = false, enabled = true, depth = 5,
            bounds = RectSnapshot(220, top + 15, 960, top + 65),
        ),
        WhatsAppUiNode(
            text = preview, contentDescription = null, className = "android.widget.TextView", viewId = null,
            clickable = false, scrollable = false, enabled = true, depth = 5,
            bounds = RectSnapshot(220, top + 78, 960, top + 132),
        ),
    )
}
'''
write("app/src/test/java/com/alothmany/wa/feature/sync/engine/WhatsAppStructuralRowParserTest.kt", structural_test)

gradle = read("app/build.gradle.kts")
gradle = gradle.replace('versionCode = 7', 'versionCode = 8', 1)
gradle = gradle.replace('versionName = "0.3.3"', 'versionName = "0.3.4"', 1)
write("app/build.gradle.kts", gradle)

workflow = read(".github/workflows/android.yml")
workflow = workflow.replace("wa-al-othmany-debug-v0.3.3", "wa-al-othmany-debug-v0.3.4")
write(".github/workflows/android.yml", workflow)

print("v0.3.4 source patch applied.")
PY

echo "Running static checks..."
grep -q 'versionName = "0.3.4"' app/build.gradle.kts
grep -q 'focused = node.isFocused' app/src/main/java/com/alothmany/wa/system/accessibility/WAAccessibilityService.kt
grep -q 'passive search EditText' app/src/main/java/com/alothmany/wa/feature/sync/engine/WhatsAppScreenDetector.kt
grep -q 'discoverRowNodes' app/src/main/java/com/alothmany/wa/feature/sync/engine/WhatsAppGroupParser.kt

git add \
  app/build.gradle.kts \
  .github/workflows/android.yml \
  app/src/main/java/com/alothmany/wa/system/accessibility/WhatsAppUiBridge.kt \
  app/src/main/java/com/alothmany/wa/system/accessibility/WAAccessibilityService.kt \
  app/src/main/java/com/alothmany/wa/feature/sync/engine/WhatsAppScreenDetector.kt \
  app/src/main/java/com/alothmany/wa/feature/sync/engine/WhatsAppGroupParser.kt \
  app/src/test/java/com/alothmany/wa/feature/sync/engine/WhatsAppScreenDetectorTest.kt \
  app/src/test/java/com/alothmany/wa/feature/sync/engine/WhatsAppStructuralRowParserTest.kt

if git diff --cached --quiet; then
  echo "No changes to commit. v0.3.4 may already be applied."
  exit 0
fi

git commit -m "Fix WhatsApp chat-list detection and structural rows v0.3.4"
git push origin main

echo "DONE: Smart Sync v0.3.4 pushed. Check GitHub Actions."
