#!/usr/bin/env bash
set -euo pipefail

ROOT="$(git rev-parse --show-toplevel 2>/dev/null || true)"
if [ -z "$ROOT" ]; then
  echo "ERROR: Run this script inside the WA-Alothmany Git repository."
  exit 1
fi
cd "$ROOT"

if [ ! -f app/build.gradle.kts ]; then
  echo "ERROR: app/build.gradle.kts not found."
  exit 1
fi

CURRENT_VERSION="$(grep -E 'versionName = ' app/build.gradle.kts | head -1 || true)"
if [[ "$CURRENT_VERSION" != *'0.3.5'* && "$CURRENT_VERSION" != *'0.3.6'* ]]; then
  echo "ERROR: v0.3.6 patch expects v0.3.5 as its base. Found: $CURRENT_VERSION"
  exit 1
fi

PAYLOAD="WA-Alothmany-Sync-v0.3.6/payload"
if [ ! -d "$PAYLOAD" ]; then
  PAYLOAD="payload"
fi
if [ ! -d "$PAYLOAD" ]; then
  echo "ERROR: v0.3.6 payload directory not found."
  exit 1
fi

cp "$PAYLOAD/app/src/main/java/com/alothmany/wa/system/accessibility/WAAccessibilityService.kt" \
  app/src/main/java/com/alothmany/wa/system/accessibility/WAAccessibilityService.kt
cp "$PAYLOAD/app/src/main/res/xml/accessibility_service_config.xml" \
  app/src/main/res/xml/accessibility_service_config.xml

python3 <<'PY'
from pathlib import Path

engine_path = Path('app/src/main/java/com/alothmany/wa/feature/sync/engine/SmartSyncEngine.kt')
text = engine_path.read_text(encoding='utf-8')

# Restore the strict runtime bridge prerequisite from the v0.3 core. Do not open
# WhatsApp if Android says enabled but the actual WAAccessibilityService process
# is not attached to the in-process bridge.
old_gate = '''            if (!integrationState.accessibility.enabled &&
                !integrationState.accessibility.serviceConnected &&
                !WhatsAppUiBridge.serviceConnected()
            ) {
                fail("خدمة Accessibility غير مفعلة أو غير متصلة")
                return
            }
'''
new_gate = '''            if (!integrationState.accessibility.enabled) {
                fail("خدمة Accessibility غير مفعلة")
                return
            }
            if (!awaitAccessibilityBridge()) {
                fail("خدمة Accessibility مفعلة ولكن محرك القراءة غير متصل. أعد تشغيل خدمة WA Al-othmany مرة واحدة")
                return
            }
'''
if old_gate in text:
    text = text.replace(old_gate, new_gate, 1)
elif 'awaitAccessibilityBridge()' not in text:
    raise SystemExit('Could not locate Accessibility readiness gate in SmartSyncEngine.kt')

# v0.3.0 worked event-first on the target device. v0.3.5 changed startup to an
# immediate cross-thread capture while WhatsApp was still entering foreground.
# Restore event-first acquisition, with captureNow only as a fallback.
old_initial = '''            delay(220)
            val initialSnapshot = WhatsAppUiBridge.captureNow(source.packageName)
                ?: awaitSnapshot(
                    packageName = source.packageName,
                    after = launchAt - 350,
                    timeoutMs = 6_000,
                )
'''
new_initial = '''            val initialSnapshot = awaitInitialWhatsAppSnapshot(
                packageName = source.packageName,
                launchAt = launchAt,
            )
'''
if old_initial in text:
    text = text.replace(old_initial, new_initial, 1)
elif 'awaitInitialWhatsAppSnapshot(' not in text:
    raise SystemExit('Could not locate v0.3.5 initial snapshot block')

# Do not force a synchronous capture on every navigation/scan iteration. It was
# not present in the working v0.3 core and can race Samsung activity transitions.
text = text.replace('            WhatsAppUiBridge.captureNow(packageName)?.let { fresh -> current = fresh }\n', '')
text = text.replace('            WhatsAppUiBridge.captureNow(packageName)?.let { fresh -> snapshot = fresh }\n', '')

# Restore the proven v0.3 scrolling mechanism. The new safety rule is that this
# is only executed after ScreenDetector has positively classified CHAT_LIST.
text = text.replace('WhatsAppUiBridge.scrollPrimaryListForward()', 'WhatsAppUiBridge.scrollForward()')
text = text.replace('WhatsAppUiBridge.scrollPrimaryListBackward()', 'WhatsAppUiBridge.scrollBackward()')

text = text.replace('Smart Sync v0.3.5', 'Smart Sync v0.3.6')
text = text.replace('Smart Sync v0.3.5 completed', 'Smart Sync v0.3.6 completed')

anchor = '''    private suspend fun awaitChangedSnapshot(
'''
helpers = '''    private suspend fun awaitAccessibilityBridge(timeoutMs: Long = 2_800L): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            if (WhatsAppUiBridge.serviceConnected()) return true
            delay(80)
        }
        return WhatsAppUiBridge.serviceConnected()
    }

    /**
     * Event-first startup restored from v0.3.0. This avoids racing the Android
     * main thread while WhatsApp is being brought to foreground. A direct fresh
     * capture is used only if normal Accessibility events do not arrive.
     */
    private suspend fun awaitInitialWhatsAppSnapshot(
        packageName: String,
        launchAt: Long,
    ): WhatsAppUiSnapshot? {
        awaitSnapshot(
            packageName = packageName,
            after = launchAt - 900,
            timeoutMs = 5_500,
        )?.takeIf { it.nodes.isNotEmpty() }?.let { return it }

        repeat(4) { attempt ->
            delay(180L + attempt * 140L)
            val captured = WhatsAppUiBridge.captureNow(packageName)
            if (captured != null && captured.packageName == packageName && captured.nodes.isNotEmpty()) {
                return captured
            }
            val latest = WhatsAppUiBridge.latest.value
            if (latest != null && latest.packageName == packageName && latest.nodes.isNotEmpty()) {
                return latest
            }
        }
        return null
    }

'''
if 'private suspend fun awaitAccessibilityBridge' not in text:
    if anchor not in text:
        raise SystemExit('Could not locate helper insertion point')
    text = text.replace(anchor, helpers + anchor, 1)

engine_path.write_text(text, encoding='utf-8')

# Screen classification: reject known non-chat surfaces first, then accept an
# explicit Chats tab even if this WhatsApp build does not expose RecyclerView or
# clickable chat-row containers to Accessibility.
detector_path = Path('app/src/main/java/com/alothmany/wa/feature/sync/engine/WhatsAppScreenDetector.kt')
d = detector_path.read_text(encoding='utf-8')
d = d.replace(
    '"channels", "channel", "updates", "status", "statuses",\n        "القنوات", "القناه", "التحديثات", "الحاله"',
    '"channels", "channel", "updates",\n        "القنوات", "القناه", "التحديثات"'
)
needle = '''        val negativeTopSurface = containsNegativeSurface(topLabels)

        if (chatTabVisible && hasPrimaryScrollable && !negativeTopSurface) {
'''
replacement = '''        val negativeTopSurface = containsNegativeSurface(topLabels)

        // Some WhatsApp/Samsung builds expose the Chats tab correctly but hide
        // RecyclerView/row semantics. Known negative surfaces were already
        // rejected above, so an explicit Chats tab is a safe home-screen signal.
        if (chatTabVisible && !negativeTopSurface) {
            return WhatsAppSurface.CHAT_LIST
        }

        if (chatTabVisible && hasPrimaryScrollable && !negativeTopSurface) {
'''
if needle in d:
    d = d.replace(needle, replacement, 1)
elif 'an explicit Chats tab is a safe home-screen signal' not in d:
    raise SystemExit('Could not locate ScreenDetector chat-list decision block')
detector_path.write_text(d, encoding='utf-8')

# Add a regression test for the exact Samsung condition: Chats label visible but
# RecyclerView/structural chat rows not exposed.
test_path = Path('app/src/test/java/com/alothmany/wa/feature/sync/engine/WhatsAppScreenDetectorTest.kt')
t = test_path.read_text(encoding='utf-8')
if 'chatTabWithoutRecyclerViewIsAcceptedOnSamsung' not in t:
    marker = '''    @Test
    fun focusedSearchFieldIsSearchSurface() {
'''
    test = '''    @Test
    fun chatTabWithoutRecyclerViewIsAcceptedOnSamsung() {
        val snapshot = snapshot(
            listOf(
                label("الدردشات", 2250).single(),
                label("محمد", 340).single(),
                label("طلاب الجامعة", 520).single(),
                label("خالد", 700).single(),
            )
        )
        assertEquals(WhatsAppSurface.CHAT_LIST, detector.classify(snapshot, parser.parse(snapshot)))
    }

'''
    if marker not in t:
        raise SystemExit('Could not insert Samsung chat-list regression test')
    t = t.replace(marker, test + marker, 1)
    test_path.write_text(t, encoding='utf-8')

# Version metadata.
build = Path('app/build.gradle.kts')
b = build.read_text(encoding='utf-8')
b = b.replace('versionCode = 9', 'versionCode = 10')
b = b.replace('versionName = "0.3.5"', 'versionName = "0.3.6"')
build.write_text(b, encoding='utf-8')

workflow = Path('.github/workflows/android.yml')
w = workflow.read_text(encoding='utf-8')
w = w.replace('wa-al-othmany-debug-v0.3.5', 'wa-al-othmany-debug-v0.3.6')
workflow.write_text(w, encoding='utf-8')
PY

# Hard safety assertions for the intended design.
ENGINE="app/src/main/java/com/alothmany/wa/feature/sync/engine/SmartSyncEngine.kt"
SCREEN="app/src/main/java/com/alothmany/wa/feature/sync/SyncScreen.kt"

if grep -q 'GROUP_FILTER_LABELS' "$ENGINE"; then
  echo "ERROR: Groups-filter automation returned. v0.3.6 must never click Groups."
  exit 1
fi
if grep -q 'clickFirstMatching(GROUP_FILTER' "$ENGINE"; then
  echo "ERROR: Groups-filter click exists."
  exit 1
fi
if grep -q 'prepareLinkedOperation' app/src/main/java/com/alothmany/wa/feature/sync/SyncViewModel.kt; then
  echo "ERROR: Sync is still wired to other operations."
  exit 1
fi
if grep -q 'link_sync_operations' "$SCREEN"; then
  echo "ERROR: Linked operations card still exists in Sync screen."
  exit 1
fi
if ! grep -q 'WhatsAppUiBridge.scrollForward()' "$ENGINE"; then
  echo "ERROR: Restored v0.3 forward scrolling is missing."
  exit 1
fi
if ! grep -q 'ARCHIVED_LABELS' "$ENGINE"; then
  echo "ERROR: Archived scan support is missing."
  exit 1
fi
if ! grep -q 'awaitAccessibilityBridge' "$ENGINE"; then
  echo "ERROR: Accessibility runtime handshake is missing."
  exit 1
fi
if ! grep -q 'versionName = "0.3.6"' app/build.gradle.kts; then
  echo "ERROR: Version bump failed."
  exit 1
fi

# XML sanity check.
python3 - <<'PY'
import xml.etree.ElementTree as ET
ET.parse('app/src/main/res/xml/accessibility_service_config.xml')
print('XML check: OK')
PY

git diff --check

# Remove temporary extracted payload after copying its files into the project.
rm -rf WA-Alothmany-Sync-v0.3.6

git add \
  app/src/main/java/com/alothmany/wa/system/accessibility/WAAccessibilityService.kt \
  app/src/main/res/xml/accessibility_service_config.xml \
  app/src/main/java/com/alothmany/wa/feature/sync/engine/SmartSyncEngine.kt \
  app/src/main/java/com/alothmany/wa/feature/sync/engine/WhatsAppScreenDetector.kt \
  app/src/test/java/com/alothmany/wa/feature/sync/engine/WhatsAppScreenDetectorTest.kt \
  app/build.gradle.kts \
  .github/workflows/android.yml \
  APPLY_SYNC_V036.sh \
  V0.3.6_CHANGES_AR.txt

git diff --cached --check

if git diff --cached --quiet; then
  echo "No changes to commit. v0.3.6 may already be applied."
  exit 0
fi

git commit -m "Restore working Smart Sync core and guard Chats only v0.3.6"
git push origin main

echo
echo "SUCCESS: v0.3.6 pushed."
echo "GitHub Actions will compile and run unit tests automatically."
