package com.alothmany.wa.system.accessibility

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * v0.3.6 restores the event-driven Accessibility capture core that was proven
 * to work on the target Samsung device in v0.3.0. Extra v0.3.5 diagnostics are
 * retained, but navigation/scrolling is based on rootInActiveWindow first.
 */
class WAAccessibilityService : AccessibilityService() {
    companion object {
        private const val MAX_NODES = 4000
        private const val SNAPSHOT_THROTTLE_MS = 80L
        private const val COMMAND_TIMEOUT_MS = 1100L
        private val TARGET_PACKAGES = setOf("com.whatsapp", "com.whatsapp.w4b")
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var lastSnapshotAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        WhatsAppUiBridge.attach(this)
        AccessibilityRuntime.connected()
        publishSnapshot(AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED, force = true)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        val packageName = event.packageName?.toString()
        if (packageName !in TARGET_PACKAGES) return

        val now = System.currentTimeMillis()
        val force = event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
            event.eventType == AccessibilityEvent.TYPE_VIEW_SCROLLED

        val snapshot = if (force || now - lastSnapshotAt >= SNAPSHOT_THROTTLE_MS) {
            publishSnapshot(event.eventType, force = force, expectedPackage = packageName)
        } else {
            null
        }

        // Keep runtime alive even when a throttled event does not create a new snapshot.
        AccessibilityRuntime.event(
            packageName = packageName,
            eventType = event.eventType,
            nodeCount = snapshot?.nodes?.size ?: AccessibilityRuntime.state.value.nodeCount,
        )
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        WhatsAppUiBridge.detach(this)
        AccessibilityRuntime.disconnected()
        super.onDestroy()
    }

    /** Fallback capture. The sync engine is event-first and calls this only as recovery. */
    internal fun captureNow(expectedPackage: String? = null): WhatsAppUiSnapshot? = onServiceThreadSnapshot {
        publishSnapshot(
            eventType = AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            force = true,
            expectedPackage = expectedPackage,
        )
    }

    internal fun clickFirstMatching(labels: Set<String>): Boolean = onServiceThread {
        val root = activeWhatsAppRoot() ?: return@onServiceThread false
        clickMatching(root, labels, safe = false)
    }

    internal fun clickSafeMatching(labels: Set<String>): Boolean = onServiceThread {
        val root = activeWhatsAppRoot() ?: return@onServiceThread false
        clickMatching(root, labels, safe = true)
    }

    internal fun scrollForward(): Boolean = onServiceThread {
        scrollAny(activeWhatsAppRoot(), AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)
    }

    internal fun scrollBackward(): Boolean = onServiceThread {
        scrollAny(activeWhatsAppRoot(), AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }

    // Kept for compatibility with other modules. Smart Sync v0.3.6 uses the proven
    // v0.3 scrollForward/scrollBackward path only after CHAT_LIST verification.
    internal fun scrollPrimaryListForward(): Boolean = scrollForward()
    internal fun scrollPrimaryListBackward(): Boolean = scrollBackward()

    internal fun performBack(): Boolean = onServiceThread {
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    private fun clickMatching(root: AccessibilityNodeInfo, labels: Set<String>, safe: Boolean): Boolean {
        val normalizedLabels = labels.map(::normalize).filter { it.isNotBlank() }
        if (normalizedLabels.isEmpty()) return false

        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        while (stack.isNotEmpty() && visited++ < MAX_NODES) {
            val node = stack.removeLast()
            val text = normalize(node.text?.toString())
            val description = normalize(node.contentDescription?.toString())
            val matches = normalizedLabels.any { label ->
                if (safe) {
                    safeLabelMatch(text, label) || safeLabelMatch(description, label)
                } else {
                    text == label || description == label ||
                        (label.length >= 4 && (text.contains(label) || description.contains(label)))
                }
            }
            if (matches && clickNodeOrParent(node)) return true
            for (index in 0 until node.childCount) node.getChild(index)?.let(stack::add)
        }
        return false
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var target: AccessibilityNodeInfo? = node
        var hops = 0
        while (target != null && !target.isClickable && hops++ < 6) target = target.parent
        return target?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
    }

    private fun safeLabelMatch(candidate: String, label: String): Boolean {
        if (candidate == label) return true
        if (candidate.startsWith(label)) {
            val suffix = candidate.substring(label.length).trimStart()
            if (suffix.isEmpty()) return true
            if (suffix.first() in setOf(',', '،', '-', '·', '•', ':') ||
                suffix.startsWith("tab") ||
                suffix.startsWith("علامة تبويب") ||
                suffix.startsWith("علامه تبويب") ||
                suffix.startsWith("غير مقرو") ||
                suffix.startsWith("unread")) return true
        }
        val tabDescription = candidate.contains("tab") ||
            candidate.contains("علامة تبويب") || candidate.contains("علامه تبويب")
        return tabDescription && (candidate.endsWith(label) || candidate.contains(" $label"))
    }

    private fun scrollAny(root: AccessibilityNodeInfo?, action: Int): Boolean {
        root ?: return false
        val candidates = ArrayList<AccessibilityNodeInfo>()
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        while (stack.isNotEmpty() && visited++ < MAX_NODES) {
            val node = stack.removeLast()
            if (node.isScrollable) candidates += node
            for (index in 0 until node.childCount) node.getChild(index)?.let(stack::add)
        }
        return candidates
            .sortedByDescending { node ->
                val rect = Rect().also { node.getBoundsInScreen(it) }
                rect.width().toLong() * rect.height().toLong()
            }
            .any { it.performAction(action) } || root.performAction(action)
    }

    private fun publishSnapshot(
        eventType: Int,
        force: Boolean,
        expectedPackage: String? = null,
    ): WhatsAppUiSnapshot? {
        val now = System.currentTimeMillis()
        if (!force && now - lastSnapshotAt < SNAPSHOT_THROTTLE_MS) return null

        val root = activeWhatsAppRoot(expectedPackage) ?: return null
        val packageName = root.packageName?.toString() ?: return null
        if (packageName !in TARGET_PACKAGES) return null

        lastSnapshotAt = now
        val rootRect = Rect().also { root.getBoundsInScreen(it) }
        val nodes = ArrayList<WhatsAppUiNode>(384)
        val stack = ArrayDeque<Pair<AccessibilityNodeInfo, Int>>()
        stack.add(root to 0)

        while (stack.isNotEmpty() && nodes.size < MAX_NODES) {
            val (node, depth) = stack.removeLast()
            val rect = Rect().also { node.getBoundsInScreen(it) }
            nodes += WhatsAppUiNode(
                text = node.text?.toString()?.take(220),
                contentDescription = node.contentDescription?.toString()?.take(220),
                className = node.className?.toString(),
                viewId = node.viewIdResourceName,
                clickable = node.isClickable,
                scrollable = node.isScrollable,
                enabled = node.isEnabled,
                depth = depth,
                bounds = RectSnapshot.from(rect),
                focused = node.isFocused,
                editable = node.isEditable,
            )
            for (index in node.childCount - 1 downTo 0) {
                node.getChild(index)?.let { child -> stack.add(child to (depth + 1)) }
            }
        }

        if (nodes.isEmpty()) return null

        val snapshot = WhatsAppUiSnapshot(
            packageName = packageName,
            eventType = eventType,
            capturedAt = now,
            rootBounds = RectSnapshot.from(rootRect),
            nodes = nodes,
        )

        AccessibilityRuntime.capture(
            packageName = packageName,
            eventType = eventType,
            nodeCount = nodes.size,
            textNodeCount = nodes.count { !it.text.isNullOrBlank() || !it.contentDescription.isNullOrBlank() },
            scrollableNodeCount = nodes.count { it.scrollable },
            interactiveWindowCount = runCatching { windows.size }.getOrDefault(0),
            captureSource = "ACTIVE_ROOT",
            capturedAt = now,
        )
        WhatsAppUiBridge.publish(snapshot)
        return snapshot
    }

    private fun activeWhatsAppRoot(expectedPackage: String? = null): AccessibilityNodeInfo? {
        val active = rootInActiveWindow
        val activePackage = active?.packageName?.toString()
        if (active != null && activePackage in TARGET_PACKAGES &&
            (expectedPackage == null || activePackage == expectedPackage)) return active

        // Recovery only: inspect interactive windows if the active root is temporarily null.
        val fallback = runCatching {
            windows.asSequence()
                .mapNotNull { it.root }
                .firstOrNull { root ->
                    val pkg = root.packageName?.toString()
                    pkg in TARGET_PACKAGES && (expectedPackage == null || pkg == expectedPackage)
                }
        }.getOrNull()
        return fallback ?: active?.takeIf { activePackage in TARGET_PACKAGES }
    }

    private fun onServiceThread(block: () -> Boolean): Boolean {
        if (Looper.myLooper() == Looper.getMainLooper()) return runCatching(block).getOrDefault(false)
        val latch = CountDownLatch(1)
        var result = false
        mainHandler.post {
            result = runCatching(block).getOrDefault(false)
            latch.countDown()
        }
        latch.await(COMMAND_TIMEOUT_MS, TimeUnit.MILLISECONDS)
        return result
    }

    private fun onServiceThreadSnapshot(block: () -> WhatsAppUiSnapshot?): WhatsAppUiSnapshot? {
        if (Looper.myLooper() == Looper.getMainLooper()) return runCatching(block).getOrNull()
        val latch = CountDownLatch(1)
        var result: WhatsAppUiSnapshot? = null
        mainHandler.post {
            result = runCatching(block).getOrNull()
            latch.countDown()
        }
        latch.await(COMMAND_TIMEOUT_MS, TimeUnit.MILLISECONDS)
        return result
    }

    private fun normalize(value: String?): String = value
        .orEmpty()
        .trim()
        .lowercase(Locale.ROOT)
        .replace(Regex("\\s+"), " ")
}
