#!/usr/bin/env bash
set -euo pipefail

PATCH_DIR="WA-Alothmany-Accessibility-Capture-v0.3.5"

if [ ! -f "settings.gradle.kts" ] || [ ! -d "app" ]; then
  echo "ERROR: Run this script from the WA-Alothmany repository root."
  exit 1
fi

if [ ! -d "$PATCH_DIR" ]; then
  echo "ERROR: $PATCH_DIR not found. Unzip the patch in the repository root first."
  exit 1
fi

echo "[1/6] Copying v0.3.5 capture-engine files..."
cp "$PATCH_DIR/app/src/main/res/xml/accessibility_service_config.xml" \
   app/src/main/res/xml/accessibility_service_config.xml
cp "$PATCH_DIR/app/src/main/java/com/alothmany/wa/system/accessibility/AccessibilityController.kt" \
   app/src/main/java/com/alothmany/wa/system/accessibility/AccessibilityController.kt
cp "$PATCH_DIR/app/src/main/java/com/alothmany/wa/system/accessibility/AccessibilityRuntime.kt" \
   app/src/main/java/com/alothmany/wa/system/accessibility/AccessibilityRuntime.kt
cp "$PATCH_DIR/app/src/main/java/com/alothmany/wa/system/accessibility/WAAccessibilityService.kt" \
   app/src/main/java/com/alothmany/wa/system/accessibility/WAAccessibilityService.kt
cp "$PATCH_DIR/app/src/main/java/com/alothmany/wa/system/accessibility/WhatsAppUiBridge.kt" \
   app/src/main/java/com/alothmany/wa/system/accessibility/WhatsAppUiBridge.kt
cp "$PATCH_DIR/app/src/main/java/com/alothmany/wa/system/integration/SystemModels.kt" \
   app/src/main/java/com/alothmany/wa/system/integration/SystemModels.kt
cp "$PATCH_DIR/app/src/main/java/com/alothmany/wa/feature/sync/engine/WhatsAppScreenDetector.kt" \
   app/src/main/java/com/alothmany/wa/feature/sync/engine/WhatsAppScreenDetector.kt
cp "$PATCH_DIR/app/src/main/java/com/alothmany/wa/feature/diagnostics/DiagnosticsViewModel.kt" \
   app/src/main/java/com/alothmany/wa/feature/diagnostics/DiagnosticsViewModel.kt
cp "$PATCH_DIR/app/src/main/java/com/alothmany/wa/feature/diagnostics/DiagnosticsScreen.kt" \
   app/src/main/java/com/alothmany/wa/feature/diagnostics/DiagnosticsScreen.kt
cp "$PATCH_DIR/app/src/test/java/com/alothmany/wa/feature/sync/engine/WhatsAppScreenDetectorTest.kt" \
   app/src/test/java/com/alothmany/wa/feature/sync/engine/WhatsAppScreenDetectorTest.kt

echo "[2/6] Patching Smart Sync integration and version..."
python3 "$PATCH_DIR/patch_repo.py"

echo "[3/6] Static validation..."
python3 - <<'PY'
from pathlib import Path
import xml.etree.ElementTree as ET
ET.parse('app/src/main/res/xml/accessibility_service_config.xml')
text = Path('app/build.gradle.kts').read_text(encoding='utf-8')
assert 'versionName = "0.3.5"' in text
assert 'versionCode = 9' in text
svc = Path('app/src/main/java/com/alothmany/wa/system/accessibility/WAAccessibilityService.kt').read_text(encoding='utf-8')
assert 'FLAG_INCLUDE_NOT_IMPORTANT_VIEWS' in svc
assert 'resolveWhatsAppRoot' in svc
assert 'captureNow' in svc
eng = Path('app/src/main/java/com/alothmany/wa/feature/sync/engine/SmartSyncEngine.kt').read_text(encoding='utf-8')
assert 'WhatsAppUiBridge.captureNow(source.packageName)' in eng
print('Static validation OK')
PY

git diff --check

echo "[4/6] Staging only v0.3.5 files..."
git add \
  .github/workflows/android.yml \
  app/build.gradle.kts \
  app/src/main/res/xml/accessibility_service_config.xml \
  app/src/main/java/com/alothmany/wa/system/accessibility/AccessibilityController.kt \
  app/src/main/java/com/alothmany/wa/system/accessibility/AccessibilityRuntime.kt \
  app/src/main/java/com/alothmany/wa/system/accessibility/WAAccessibilityService.kt \
  app/src/main/java/com/alothmany/wa/system/accessibility/WhatsAppUiBridge.kt \
  app/src/main/java/com/alothmany/wa/system/integration/SystemModels.kt \
  app/src/main/java/com/alothmany/wa/feature/sync/engine/WhatsAppScreenDetector.kt \
  app/src/main/java/com/alothmany/wa/feature/sync/engine/SmartSyncEngine.kt \
  app/src/main/java/com/alothmany/wa/feature/sync/SyncViewModel.kt \
  app/src/main/java/com/alothmany/wa/feature/diagnostics/DiagnosticsViewModel.kt \
  app/src/main/java/com/alothmany/wa/feature/diagnostics/DiagnosticsScreen.kt \
  app/src/test/java/com/alothmany/wa/feature/sync/engine/WhatsAppScreenDetectorTest.kt

if git diff --cached --quiet; then
  echo "No new changes to commit. v0.3.5 may already be applied."
  exit 0
fi

echo "[5/6] Creating commit..."
git commit -m "Harden WhatsApp accessibility capture v0.3.5"

echo "[6/6] Pushing main..."
git push origin main

echo
echo "DONE: v0.3.5 pushed. GitHub Actions will build and test the APK."
