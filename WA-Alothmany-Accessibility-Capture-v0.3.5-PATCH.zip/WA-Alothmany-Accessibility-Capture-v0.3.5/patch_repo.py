from pathlib import Path

root = Path.cwd()


def replace_exact(path: str, old: str, new: str, required=True):
    p = root / path
    text = p.read_text(encoding="utf-8")
    if old not in text:
        if new in text:
            print(f"already patched: {path}")
            return
        if required:
            raise SystemExit(f"Expected block not found in {path}")
        print(f"optional block not found: {path}")
        return
    p.write_text(text.replace(old, new, 1), encoding="utf-8")
    print(f"patched: {path}")


# SmartSyncEngine: accept a live connected service even if the Android enabled-list cache is stale.
replace_exact(
    "app/src/main/java/com/alothmany/wa/feature/sync/engine/SmartSyncEngine.kt",
    '''            if (!integrationState.accessibility.enabled) {\n                fail("خدمة Accessibility غير مفعلة")\n                return\n            }''',
    '''            if (!integrationState.accessibility.enabled &&\n                !integrationState.accessibility.serviceConnected &&\n                !WhatsAppUiBridge.serviceConnected()\n            ) {\n                fail("خدمة Accessibility غير مفعلة أو غير متصلة")\n                return\n            }''',
)

# Force a fresh tree immediately after WhatsApp opens, then fall back to event waiting.
replace_exact(
    "app/src/main/java/com/alothmany/wa/feature/sync/engine/SmartSyncEngine.kt",
    '''            val initialSnapshot = awaitSnapshot(\n                packageName = source.packageName,\n                after = launchAt - 350,\n                timeoutMs = 6_000,\n            )''',
    '''            delay(220)\n            val initialSnapshot = WhatsAppUiBridge.captureNow(source.packageName)\n                ?: awaitSnapshot(\n                    packageName = source.packageName,\n                    after = launchAt - 350,\n                    timeoutMs = 6_000,\n                )''',
)

# Refresh the tree at the beginning of every navigation recovery pass.
replace_exact(
    "app/src/main/java/com/alothmany/wa/feature/sync/engine/SmartSyncEngine.kt",
    '''            awaitResumeIfPaused()\n\n            val parsed = parser.parse(current)''',
    '''            awaitResumeIfPaused()\n\n            WhatsAppUiBridge.captureNow(packageName)?.let { fresh -> current = fresh }\n            val parsed = parser.parse(current)''',
)

# Refresh every scan pass too, so a stale snapshot cannot stop scrolling early.
replace_exact(
    "app/src/main/java/com/alothmany/wa/feature/sync/engine/SmartSyncEngine.kt",
    '''            if (stopRequested.get()) break\n\n            val parsed = parser.parse(snapshot)''',
    '''            if (stopRequested.get()) break\n\n            WhatsAppUiBridge.captureNow(packageName)?.let { fresh -> snapshot = fresh }\n            val parsed = parser.parse(snapshot)''',
)

# Version wording only; functional behavior above is what matters.
engine = root / "app/src/main/java/com/alothmany/wa/feature/sync/engine/SmartSyncEngine.kt"
text = engine.read_text(encoding="utf-8")
text = text.replace("Smart Sync v0.3.3", "Smart Sync v0.3.5")
engine.write_text(text, encoding="utf-8")

# Sync UI readiness should trust a live service as well as the settings capability bit.
replace_exact(
    "app/src/main/java/com/alothmany/wa/feature/sync/SyncViewModel.kt",
    '''            accessibilityReady = baseState.system.accessibility.enabled,\n            canStart = source?.launchable == true && baseState.system.accessibility.enabled,''',
    '''            accessibilityReady = baseState.system.accessibility.enabled || baseState.system.accessibility.serviceConnected,\n            canStart = source?.launchable == true &&\n                (baseState.system.accessibility.enabled || baseState.system.accessibility.serviceConnected),''',
)

# Version and artifact names.
replace_exact("app/build.gradle.kts", 'versionCode = 8', 'versionCode = 9')
replace_exact("app/build.gradle.kts", 'versionName = "0.3.4"', 'versionName = "0.3.5"')
replace_exact(".github/workflows/android.yml", 'name: wa-al-othmany-debug-v0.3.4', 'name: wa-al-othmany-debug-v0.3.5')
