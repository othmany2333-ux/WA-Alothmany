WA Al-othmany v0.3.5 - Accessibility Capture Engine

Purpose:
- Capture more WhatsApp UI nodes on Samsung/One UI.
- Read from interactive WhatsApp windows when rootInActiveWindow is incomplete.
- Force fresh snapshots before navigation and scanning decisions.
- Distinguish passive search boxes from focused search.
- Provide live capture diagnostics (nodes, text nodes, scrollables, windows, surface, chat rows, group candidates).
- Keep Smart Sync independent from extraction/publish/join/delete/contact engines.

No private WhatsApp database access is used. No Knox/profile security is bypassed.
