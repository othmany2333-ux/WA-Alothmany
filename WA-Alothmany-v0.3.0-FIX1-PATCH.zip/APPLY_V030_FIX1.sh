#!/usr/bin/env bash
set -euo pipefail
ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
cd "$ROOT"
FILE="app/src/main/java/com/alothmany/wa/feature/sync/SyncScreen.kt"
if [ ! -f "$FILE" ]; then
  echo "ERROR: $FILE not found. Run this inside the WA-Alothmany repository."
  exit 1
fi
python3 - <<'PY'
from pathlib import Path
p = Path("app/src/main/java/com/alothmany/wa/feature/sync/SyncScreen.kt")
s = p.read_text(encoding="utf-8")
old_if = "            if (state.sourceName != null) {"
new_if = "            val sourceName = state.sourceName\n            if (sourceName != null) {"
old_arg = "stringResource(R.string.sync_current_source, state.sourceName)"
new_arg = "stringResource(R.string.sync_current_source, sourceName)"
if old_if not in s or old_arg not in s:
    if "val sourceName = state.sourceName" in s and new_arg in s:
        print("Fix already applied.")
        raise SystemExit(0)
    raise SystemExit("ERROR: Expected v0.3.0 sourceName snippet was not found; repository may have changed.")
s = s.replace(old_if, new_if, 1)
s = s.replace(old_arg, new_arg, 1)
p.write_text(s, encoding="utf-8")
print("Patched SyncScreen.kt successfully.")
PY

grep -n "val sourceName = state.sourceName" "$FILE"
grep -n "sync_current_source, sourceName" "$FILE"

git add "$FILE"
if git diff --cached --quiet; then
  echo "No new changes to commit."
  exit 0
fi

git commit -m "Fix Smart Sync sourceName Compose smart cast"
git push origin main

echo "FIX1 pushed. GitHub Actions will start automatically."
