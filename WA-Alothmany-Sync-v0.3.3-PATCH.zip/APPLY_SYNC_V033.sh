#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
PATCH_DIR="$ROOT/WA-Alothmany-Sync-v0.3.3"

if [ ! -f "$ROOT/settings.gradle.kts" ] || [ ! -d "$ROOT/app" ]; then
  echo "ERROR: Run this script from the WA-Alothmany repository root."
  exit 1
fi
if [ ! -d "$PATCH_DIR" ]; then
  echo "ERROR: WA-Alothmany-Sync-v0.3.3 directory not found. Unzip the patch first."
  exit 1
fi

echo "[1/7] Installing Smart Sync v0.3.3 engine files..."
cp "$PATCH_DIR/app/src/main/java/com/alothmany/wa/feature/sync/model/SyncModels.kt" \
   "$ROOT/app/src/main/java/com/alothmany/wa/feature/sync/model/SyncModels.kt"
cp "$PATCH_DIR/app/src/main/java/com/alothmany/wa/feature/sync/engine/WhatsAppGroupParser.kt" \
   "$ROOT/app/src/main/java/com/alothmany/wa/feature/sync/engine/WhatsAppGroupParser.kt"
cp "$PATCH_DIR/app/src/main/java/com/alothmany/wa/feature/sync/engine/WhatsAppScreenDetector.kt" \
   "$ROOT/app/src/main/java/com/alothmany/wa/feature/sync/engine/WhatsAppScreenDetector.kt"
cp "$PATCH_DIR/app/src/main/java/com/alothmany/wa/feature/sync/engine/SmartSyncEngine.kt" \
   "$ROOT/app/src/main/java/com/alothmany/wa/feature/sync/engine/SmartSyncEngine.kt"
mkdir -p "$ROOT/app/src/test/java/com/alothmany/wa/feature/sync/engine"
cp "$PATCH_DIR/app/src/test/java/com/alothmany/wa/feature/sync/engine/WhatsAppGroupParserTest.kt" \
   "$ROOT/app/src/test/java/com/alothmany/wa/feature/sync/engine/WhatsAppGroupParserTest.kt"
cp "$PATCH_DIR/app/src/test/java/com/alothmany/wa/feature/sync/engine/WhatsAppScreenDetectorTest.kt" \
   "$ROOT/app/src/test/java/com/alothmany/wa/feature/sync/engine/WhatsAppScreenDetectorTest.kt"

echo "[2/7] Patching UI readiness, fingerprints, Accessibility navigation, and version..."
python3 - <<'PY'
from pathlib import Path
import re

root = Path.cwd()

# Version
p = root / 'app/build.gradle.kts'
s = p.read_text()
s = re.sub(r'versionCode\s*=\s*\d+', 'versionCode = 7', s, count=1)
s = re.sub(r'versionName\s*=\s*"[^"]+"', 'versionName = "0.3.3"', s, count=1)
p.write_text(s)

# SyncViewModel: expose stable fingerprint and allow start when Accessibility is enabled;
# the engine waits for the actual WhatsApp snapshot after launch.
p = root / 'app/src/main/java/com/alothmany/wa/feature/sync/SyncViewModel.kt'
s = p.read_text()
if 'val fingerprint: String,' not in s:
    s = s.replace(
        '    val confidence: String,\n    val selected: Boolean,',
        '    val confidence: String,\n    val fingerprint: String,\n    val selected: Boolean,'
    )
if 'fingerprint = group.fingerprint,' not in s:
    s = s.replace(
        '                confidence = meta?.confidence ?: "UNKNOWN",\n                selected = group.id in selection,',
        '                confidence = meta?.confidence ?: "UNKNOWN",\n                fingerprint = group.fingerprint,\n                selected = group.id in selection,'
    )
s = s.replace(
    '            accessibilityReady = baseState.system.accessibility.enabled && baseState.system.accessibility.serviceConnected,\n            canStart = source?.launchable == true && baseState.system.accessibility.enabled && baseState.system.accessibility.serviceConnected,',
    '            accessibilityReady = baseState.system.accessibility.enabled,\n            canStart = source?.launchable == true && baseState.system.accessibility.enabled,'
)
p.write_text(s)

# Sync UI: show stable fingerprint and current version badge.
p = root / 'app/src/main/java/com/alothmany/wa/feature/sync/SyncScreen.kt'
s = p.read_text()
s = s.replace('else "v0.3"', 'else "v0.3.3"')
needle = '            Text(group.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)\n            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {'
if needle in s and 'FP ${group.fingerprint.take(12)}' not in s:
    repl = '''            Text(group.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)\n            if (group.fingerprint.isNotBlank()) {\n                Text(\n                    "FP ${group.fingerprint.take(12)}",\n                    color = MaterialTheme.colorScheme.onSurfaceVariant,\n                    fontSize = 9.sp,\n                    maxLines = 1,\n                )\n            }\n            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {'''
    s = s.replace(needle, repl)
p.write_text(s)

# Accessibility tab-label matching: support "Tab, Chats" / "علامة تبويب، الدردشات"
p = root / 'app/src/main/java/com/alothmany/wa/system/accessibility/WAAccessibilityService.kt'
s = p.read_text()
old = '''    private fun safeLabelMatch(candidate: String, label: String): Boolean {\n        if (candidate == label) return true\n        if (!candidate.startsWith(label)) return false\n        if (candidate.length == label.length) return true\n        val suffix = candidate.substring(label.length).trimStart()\n        if (suffix.isEmpty()) return true\n        return suffix.first() in setOf(',', '،', '-', '·', '•', ':') ||\n            suffix.startsWith("tab") ||\n            suffix.startsWith("علامة تبويب") ||\n            suffix.startsWith("غير مقرو") ||\n            suffix.startsWith("unread")\n    }'''
new = '''    private fun safeLabelMatch(candidate: String, label: String): Boolean {\n        if (candidate == label) return true\n\n        if (candidate.startsWith(label)) {\n            val suffix = candidate.substring(label.length).trimStart()\n            if (suffix.isEmpty()) return true\n            if (suffix.first() in setOf(',', '،', '-', '·', '•', ':') ||\n                suffix.startsWith("tab") ||\n                suffix.startsWith("علامة تبويب") ||\n                suffix.startsWith("علامه تبويب") ||\n                suffix.startsWith("غير مقرو") ||\n                suffix.startsWith("unread")) return true\n        }\n\n        val tabDescription = candidate.contains("tab") ||\n            candidate.contains("علامة تبويب") ||\n            candidate.contains("علامه تبويب")\n        if (tabDescription && (candidate.endsWith(label) || candidate.contains(" $label"))) return true\n        return false\n    }'''
if old in s:
    s = s.replace(old, new)
else:
    print('WARN: safeLabelMatch block was not the expected version; leaving it unchanged.')
p.write_text(s)

# Clarify that contact controls are independent from group scanning.
for rel in ['app/src/main/res/values-ar/strings.xml', 'app/src/main/res/values/strings.xml']:
    p = root / rel
    if not p.exists():
        continue
    s = p.read_text()
    if rel.endswith('values-ar/strings.xml'):
        replacement = '<string name="contact_sync_phase_note">خيارات جهات الاتصال مستقلة ولا تؤثر على مزامنة القروبات. سيتم تفعيل مسح الأرقام لاحقًا بعد تثبيت محرك القروبات.</string>'
    else:
        replacement = '<string name="contact_sync_phase_note">Contact options are independent and do not affect group sync. Number scanning will be enabled after the group engine is validated.</string>'
    s = re.sub(r'<string name="contact_sync_phase_note">.*?</string>', replacement, s)
    p.write_text(s)

# Artifact naming only; does not change APK contents.
p = root / '.github/workflows/android.yml'
if p.exists():
    s = p.read_text()
    s = re.sub(r'wa-al-othmany-debug-v0\.[0-9.]+', 'wa-al-othmany-debug-v0.3.3', s)
    p.write_text(s)
PY

echo "[3/7] Static consistency checks..."
grep -q 'versionName = "0.3.3"' app/build.gradle.kts
grep -q 'identityFingerprint' app/src/main/java/com/alothmany/wa/feature/sync/engine/WhatsAppGroupParser.kt
grep -q 'WhatsAppScreenDetector' app/src/main/java/com/alothmany/wa/feature/sync/engine/SmartSyncEngine.kt
grep -q 'FP ${group.fingerprint.take(12)}' app/src/main/java/com/alothmany/wa/feature/sync/SyncScreen.kt

echo "[4/7] Focused tests are installed for GitHub Actions."
echo "Skipping local Gradle build to save Codespace time/data and avoid environment-specific failures."

echo "[5/7] GitHub Actions will run compile + unit tests after push."

echo "[6/7] Staging Phase v0.3.3 changes..."
git add \
  app/build.gradle.kts \
  app/src/main/java/com/alothmany/wa/feature/sync/model/SyncModels.kt \
  app/src/main/java/com/alothmany/wa/feature/sync/engine/WhatsAppGroupParser.kt \
  app/src/main/java/com/alothmany/wa/feature/sync/engine/WhatsAppScreenDetector.kt \
  app/src/main/java/com/alothmany/wa/feature/sync/engine/SmartSyncEngine.kt \
  app/src/main/java/com/alothmany/wa/feature/sync/SyncViewModel.kt \
  app/src/main/java/com/alothmany/wa/feature/sync/SyncScreen.kt \
  app/src/main/java/com/alothmany/wa/system/accessibility/WAAccessibilityService.kt \
  app/src/test/java/com/alothmany/wa/feature/sync/engine/WhatsAppGroupParserTest.kt \
  app/src/test/java/com/alothmany/wa/feature/sync/engine/WhatsAppScreenDetectorTest.kt \
  app/src/main/res/values-ar/strings.xml \
  app/src/main/res/values/strings.xml \
  .github/workflows/android.yml

if git diff --cached --quiet; then
  echo "No staged changes. v0.3.3 may already be applied."
  exit 0
fi

echo "[7/7] Commit and push..."
git commit -m "Rebuild Smart Sync group discovery v0.3.3"
git push origin main

echo
echo "DONE: Smart Sync v0.3.3 pushed. GitHub Actions should start automatically."
