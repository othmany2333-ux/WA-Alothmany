WA Al-othmany v0.2.1 - Permission Center Patch

1) ارفع ملف ZIP إلى جذر مستودع WA-Alothmany على GitHub.
2) افتح Codespace ثم نفذ:
   git pull origin main
   unzip -o WA-Alothmany-Permission-Center-v0.2.1-PATCH.zip
   bash APPLY_PERMISSION_CENTER.sh

السكربت يعدل الواجهة والمنطق، ثم يعمل commit و push تلقائيا.
