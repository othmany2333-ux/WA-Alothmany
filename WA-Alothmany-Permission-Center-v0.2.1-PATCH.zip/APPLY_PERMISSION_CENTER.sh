#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
if [ ! -f "$ROOT/settings.gradle.kts" ] || [ ! -d "$ROOT/app" ]; then
  echo "ERROR: Run this script from the WA-Alothmany repository root."
  exit 1
fi

python3 <<'PY'
from pathlib import Path


def replace_once(path, old, new, label):
    p = Path(path)
    s = p.read_text(encoding="utf-8")
    if new in s:
        print(f"[OK] {label}: already applied")
        return
    if old not in s:
        raise SystemExit(f"[ERROR] Could not find expected block for {label} in {path}")
    p.write_text(s.replace(old, new, 1), encoding="utf-8")
    print(f"[OK] {label}")

# 1) Make the common status card actionable while keeping old call sites compatible.
replace_once(
    "app/src/main/java/com/alothmany/wa/core/ui/components/CommonComponents.kt",
    '''@Composable
fun StatusPill(
    title: String,
    status: String,
    icon: ImageVector,
    color: Color,
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .85f),
        border = BorderStroke(1.dp, color.copy(alpha = .35f)),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Icon(icon, null, tint = color, modifier = Modifier.size(20.dp))
            Column {
                Text(title, style = MaterialTheme.typography.labelLarge, maxLines = 1)
                Text(status, color = color, fontSize = 11.sp, maxLines = 1)
            }
        }
    }
}
''',
    '''@Composable
fun StatusPill(
    title: String,
    status: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    actionText: String? = null,
    onClick: (() -> Unit)? = null,
) {
    val interactiveModifier = if (onClick != null) {
        modifier.clickable(onClick = onClick)
    } else {
        modifier
    }

    Surface(
        modifier = interactiveModifier,
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = .85f),
        border = BorderStroke(1.dp, color.copy(alpha = .35f)),
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Icon(icon, null, tint = color, modifier = Modifier.size(20.dp))
            Column {
                Text(title, style = MaterialTheme.typography.labelLarge, maxLines = 1)
                Text(status, color = color, fontSize = 11.sp, maxLines = 1)
                if (!actionText.isNullOrBlank()) {
                    Text(
                        actionText,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                    )
                }
            }
        }
    }
}
''',
    "actionable StatusPill",
)

# 2) Expose permission actions to the dashboard.
replace_once(
    "app/src/main/java/com/alothmany/wa/feature/dashboard/DashboardViewModel.kt",
    '''    fun refreshSystem() = systemIntegration.refresh()

    fun setSource(source: WhatsAppSourceType) = viewModelScope.launch {
''',
    '''    fun refreshSystem() = systemIntegration.refresh()
    fun configureShizuku() = systemIntegration.configureShizuku()
    fun configureAccessibility() = systemIntegration.configureAccessibility()
    fun toggleOverlay() = systemIntegration.toggleOverlay()
    fun probeSources() = systemIntegration.probeSources()

    fun setSource(source: WhatsAppSourceType) = viewModelScope.launch {
''',
    "dashboard permission actions",
)

# 3) Turn the three capability cards on Home into real action buttons.
replace_once(
    "app/src/main/java/com/alothmany/wa/feature/dashboard/DashboardScreen.kt",
    '''            StatusPill(
                stringResource(R.string.shizuku),
                capabilityText(state.system.shizuku.status),
                Icons.Rounded.Terminal,
                capabilityColor(state.system.shizuku.status),
            )
            StatusPill(
                stringResource(R.string.accessibility),
                stringResource(
                    if (state.system.accessibility.enabled) R.string.enabled
                    else R.string.permission_required
                ),
                Icons.Rounded.AccessibilityNew,
                if (state.system.accessibility.enabled) Green400 else Blue400,
            )
            StatusPill(
                stringResource(R.string.overlay),
                stringResource(
                    when {
                        state.system.overlayRunning -> R.string.running
                        state.system.overlayPermissionGranted -> R.string.ready
                        else -> R.string.permission_required
                    }
                ),
                Icons.Rounded.Layers,
                if (state.system.overlayRunning) Green400 else Purple400,
            )
''',
    '''            StatusPill(
                title = stringResource(R.string.shizuku),
                status = capabilityText(state.system.shizuku.status),
                icon = Icons.Rounded.Terminal,
                color = capabilityColor(state.system.shizuku.status),
                actionText = stringResource(
                    if (state.system.shizuku.permissionGranted) R.string.recheck
                    else R.string.grant_permission
                ),
                onClick = {
                    if (state.system.shizuku.permissionGranted) viewModel.refreshSystem()
                    else viewModel.configureShizuku()
                },
            )
            StatusPill(
                title = stringResource(R.string.accessibility),
                status = stringResource(
                    if (state.system.accessibility.enabled) R.string.enabled
                    else R.string.permission_required
                ),
                icon = Icons.Rounded.AccessibilityNew,
                color = if (state.system.accessibility.enabled) Green400 else Blue400,
                actionText = stringResource(
                    if (state.system.accessibility.enabled) R.string.manage_permission
                    else R.string.grant_permission
                ),
                onClick = viewModel::configureAccessibility,
            )
            StatusPill(
                title = stringResource(R.string.overlay),
                status = stringResource(
                    when {
                        state.system.overlayRunning -> R.string.running
                        state.system.overlayPermissionGranted -> R.string.ready
                        else -> R.string.permission_required
                    }
                ),
                icon = Icons.Rounded.Layers,
                color = if (state.system.overlayRunning) Green400 else Purple400,
                actionText = stringResource(
                    when {
                        state.system.overlayRunning -> R.string.stop_overlay
                        state.system.overlayPermissionGranted -> R.string.start_overlay
                        else -> R.string.grant_permission
                    }
                ),
                onClick = viewModel::toggleOverlay,
            )
''',
    "dashboard permission cards",
)

# 4) Turn Settings into a unified Permission Center with clearer actions.
replace_once(
    "app/src/main/java/com/alothmany/wa/feature/settings/SettingsScreen.kt",
    '            SectionTitle(stringResource(R.string.permissions_system))\n',
    '            SectionTitle(stringResource(R.string.permission_center))\n',
    "permission center title",
)
replace_once(
    "app/src/main/java/com/alothmany/wa/feature/settings/SettingsScreen.kt",
    '''                actionText = stringResource(
                    if (system.shizuku.permissionGranted) R.string.recheck
                    else R.string.configure
                ),
''',
    '''                actionText = stringResource(
                    if (system.shizuku.permissionGranted) R.string.recheck
                    else R.string.grant_permission
                ),
''',
    "Shizuku action label",
)
replace_once(
    "app/src/main/java/com/alothmany/wa/feature/settings/SettingsScreen.kt",
    '''                actionText = stringResource(R.string.configure),
                onAction = viewModel::configureAccessibility,
''',
    '''                actionText = stringResource(
                    if (system.accessibility.enabled) R.string.manage_permission
                    else R.string.grant_permission
                ),
                onAction = viewModel::configureAccessibility,
''',
    "Accessibility action label",
)
replace_once(
    "app/src/main/java/com/alothmany/wa/feature/settings/SettingsScreen.kt",
    '''                        system.overlayPermissionGranted -> R.string.start_overlay
                        else -> R.string.configure
''',
    '''                        system.overlayPermissionGranted -> R.string.start_overlay
                        else -> R.string.grant_permission
''',
    "Overlay action label",
)

# 5) Add localized Permission Center strings.
for path, old, new, label in [
    (
        "app/src/main/res/values/strings.xml",
        '    <string name="permissions_system">System &amp; permissions</string>\n',
        '    <string name="permissions_system">System &amp; permissions</string>\n'
        '    <string name="permission_center">Permission center</string>\n'
        '    <string name="grant_permission">Grant permission</string>\n'
        '    <string name="manage_permission">Manage permission</string>\n',
        "English permission strings",
    ),
    (
        "app/src/main/res/values-ar/strings.xml",
        '    <string name="permissions_system">النظام والصلاحيات</string>\n',
        '    <string name="permissions_system">النظام والصلاحيات</string>\n'
        '    <string name="permission_center">مركز الصلاحيات</string>\n'
        '    <string name="grant_permission">منح الصلاحية</string>\n'
        '    <string name="manage_permission">إدارة الصلاحية</string>\n',
        "Arabic permission strings",
    ),
]:
    replace_once(path, old, new, label)

# 6) Mark this small UI/system improvement as v0.2.1.
build = Path("app/build.gradle.kts")
s = build.read_text(encoding="utf-8")
if 'versionName = "0.2.1"' not in s:
    if 'versionCode = 2' not in s or 'versionName = "0.2.0"' not in s:
        raise SystemExit("[ERROR] Unexpected app version; refusing to bump automatically")
    s = s.replace('versionCode = 2', 'versionCode = 3', 1)
    s = s.replace('versionName = "0.2.0"', 'versionName = "0.2.1"', 1)
    build.write_text(s, encoding="utf-8")
    print("[OK] version bumped to 0.2.1")
else:
    print("[OK] version already 0.2.1")

print("\nPermission Center patch applied successfully.")
PY

# Basic pre-commit validation that does not require Android SDK.
git diff --check

echo ""
echo "Changed files:"
git status --short

git add \
  app/build.gradle.kts \
  app/src/main/java/com/alothmany/wa/core/ui/components/CommonComponents.kt \
  app/src/main/java/com/alothmany/wa/feature/dashboard/DashboardViewModel.kt \
  app/src/main/java/com/alothmany/wa/feature/dashboard/DashboardScreen.kt \
  app/src/main/java/com/alothmany/wa/feature/settings/SettingsScreen.kt \
  app/src/main/res/values/strings.xml \
  app/src/main/res/values-ar/strings.xml

if git diff --cached --quiet; then
  echo "No new changes to commit."
  exit 0
fi

git commit -m "Add smart permission center v0.2.1"
git push origin main

echo ""
echo "DONE: v0.2.1 Permission Center pushed to GitHub."
echo "GitHub Actions should start automatically."
